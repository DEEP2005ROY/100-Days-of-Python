# Blackjack Project

This is a simple console-based Blackjack game implemented in Python.

## Rules

- The deck is unlimited in size.
- There are no jokers.
- The Jack/Queen/King all count as 10.
- The Ace can count as 11 or 1.
- The cards in the list have equal probability of being drawn.
- Cards are not removed from the deck as they are drawn.

## How to Play

- Run the script in your Python environment.
- You will be dealt two cards to start the game.
- Choose whether to draw another card or pass.
- If your score exceeds 21, you lose.
- If you pass, the computer will draw cards until its score is 17 or more.
- After the computer finishes drawing cards, the scores are compared and the winner is determined.

## Code Overview

- `deal_card()`: This function is used to draw a card from the deck.
- `calculate_score(cards)`: This function is used to calculate the current score of a hand.
- `compare(user_score, computer_score)`: This function is used to determine the winner of the game.
- `play_game()`: This function starts a new game of Blackjack.

Enjoy the game!
