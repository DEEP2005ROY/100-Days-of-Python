# Hangman Game

## Description
This is a simple implementation of the classic Hangman game in Python. The game selects a random word from a list and the player has to guess it one letter at a time. The player has 6 lives, and they lose a life for every incorrect guess. If the player guesses the word before running out of lives, they win!

## How to Run
1. Ensure you have Python installed on your system.
2. Clone this repository or download the files.
3. Run the script using the command `python hangman.py`.

## Game Rules
1. The game starts by picking a random word.
2. The player guesses one letter at a time.
3. If the guessed letter is in the word, all occurrences of the letter in the word are revealed.
4. If the guessed letter is not in the word, the player loses a life.
5. If the player loses all their lives before guessing the word, they lose.
6. If the player guesses all the letters in the word before losing all their lives, they win!

## Files
- `hangman.py`: This is the main script that runs the game.
- `hangman_words.py`: This file contains the list of possible words for the game.
- `hangman_art.py`: This file contains the ASCII art for the hangman and the game logo.

Enjoy the game!
