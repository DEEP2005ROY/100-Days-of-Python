# Pong Game

This is a simple implementation of the classic Pong arcade game using Python's turtle module.

## Game Overview

Two players control paddles by dragging them up and down to hit the ball back and forth. The goal is to make your opponent miss the ball.

## How to Run the Game

1. Ensure you have Python installed on your computer.
2. Clone this repository to your local machine.
3. Run the `main.py` file in your Python environment.

## Controls

- Player 1:
    - 'w' to move the paddle up
    - 's' to move the paddle down

- Player 2:
    - 'Up' arrow key to move the paddle up
    - 'Down' arrow key to move the paddle down

## Game Rules

- The ball bounces off the top and bottom edges of the screen.
- If a player misses the ball and it hits their edge of the screen, the other player scores a point.
- The game continues until the program is closed.

Enjoy the game!
