# Number Guessing Game

This is a simple console-based number guessing game implemented in Python.

## Rules

- The game randomly selects a number between 1 and 100.
- The player chooses a difficulty level, which determines the number of attempts they have to guess the number. The 'easy' level gives the player 10 attempts, while the 'hard' level gives them 5 attempts.
- The player then enters their guess. If the guess is correct, they win the game. If the guess is too high or too low, the game informs them and decrements the number of remaining attempts.
- The game continues until the player guesses the number correctly or runs out of attempts.

## How to Play

- Run the script in your Python environment.
- Choose your difficulty level.
- Make your guess.
- Continue guessing until you guess the number correctly or run out of attempts.

## Code Overview

- `guess_number()`: This function takes the player's guess, compares it with the randomly selected number, and provides feedback to the player.

Enjoy the game!
