import requests
import lxml
from bs4 import BeautifulSoup
import smtplib

SENDER_EMAIL = "YOUR_EMAIL"
SENDER_PASS = "YOUR_GMAIL_APP_PASSWORD"

URL = "YOUR_FAVOURITE_PRODUCT_URL"
header = {
    "User-Agent": "",
    "Accept-Language": ""

    #User-Agent,Accept-Language available at"http://myhttpheader.com/"
}
response = requests.get(URL, headers=header)
soup = BeautifulSoup(response.content, "lxml")
print(soup.prettify())

soup = BeautifulSoup(response.content, "lxml")
whole_price = soup.find(name="span", class_="a-price-whole")
fraction_price = soup.find(name="span", class_="a-price-fraction")
final_price = float(whole_price.getText() + fraction_price.getText())
print(final_price)

product_title = soup.find(id="productTitle").get_text().strip()
print(product_title)

target_price = "YOUR_DESIRED_TARGET_PRICE"
if final_price < target_price:
    connection = smtplib.SMTP("smtp.gmail.com", port=587)
    connection.starttls()
    connection.login(user=SENDER_EMAIL, password=SENDER_PASS)
    message = f"{product_title} is now {final_price}\n{URL}"
    receiver_mail = "RECEIVER_EMAIL"
    connection.sendmail(
        from_addr=SENDER_EMAIL,
        to_addrs=receiver_mail,
        msg=f"Subject:Amazon Price Alert\n\n{message}".encode('utf-8')
    )
    connection.close()
