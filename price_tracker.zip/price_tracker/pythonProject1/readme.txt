# Amazon Price Tracker

This Python script tracks the price of a specific product on Amazon and sends an email alert when the price drops below a specified target price.

## Requirements

- Python 3.x
- `requests` library
- `beautifulsoup4` library
- `lxml` parser
- `smtplib` (part of the Python Standard Library)

You can install the required libraries using pip:
```sh
pip install requests beautifulsoup4 lxml

Setup
1.Email Setup:

Create a Gmail account if you don't have one.
Enable "Less secure app access" or create an App Password for your Gmail account.

2.Script Configuration:

Replace "YOUR_EMAIL" with your Gmail address.
Replace "YOUR_GMAIL_APP_PASSWORD" with your Gmail App Password.
Replace "YOUR_FAVOURITE_PRODUCT_URL" with the URL of the Amazon product you want to track.
Replace "YOUR_USER_AGENT" and "YOUR_ACCEPT_LANGUAGE" with appropriate values from "myhttpheader.com."
Replace "YOUR_DESIRED_TARGET_PRICE" with the target price you want to track.
Replace "RECEIVER_EMAIL" with the email address where you want to receive the price alert.


EXAMPLE:-

SENDER_EMAIL = "rdeepjyoti728@gmail.com"
SENDER_PASS = "your_app_password"

URL = "https://www.amazon.com/dp/B075CYMYK6?ref_=cm_sw_r_cp_ud_ct_FM9M699VKHTT47YD50Q6&th=1"
headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36",
    "Accept-Language": "en-GB,en-US;q=0.9,en;q=0.8"
}

target_price = 500
receiver_email = "receiver@example.com"
