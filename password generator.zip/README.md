## Password Generator

# Instructions

The program will ask:
```
How many letters would you like in your password?
```
```
How many symbols would you like?
```
```
How many numbers would you like?
```
The objective is to take the inputs from the user to these questions and then generate a random password. Use your knowledge about Python lists and loops to complete the challenge. 

# Easy Version (Step 1)

Generate the password in sequence. If the user wants 
* 4 letters
* 2 symbols and
* 3 numbers

then the password might look like this: 

```
fgdx$*924
```
You can see that all the letters are together. All the symbols are together and all the numbers follow each other as well.
And every time you generate a password, the positions of the symbols, numbers, and letters are different. 


