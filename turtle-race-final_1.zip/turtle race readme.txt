# Turtle Race Game

This is a simple and fun game implemented in Python using the `turtle` module. In this game, six turtles compete in a race, and the user bets on which turtle will win.

## How to Play

When you run the script, a graphical window will open with six turtles of different colors at the starting line. A dialog box will prompt you to enter the color of the turtle you think will win the race.

Once you place your bet, the race begins. Each turtle moves forward a random distance in each iteration of the main loop. The race continues until one of the turtles crosses the finish line.

If the color of the winning turtle matches your bet, a message is printed to the console stating that you've won. Otherwise, a message is printed stating that you've lost.

## Requirements

This script requires Python's built-in `turtle` module for creating the graphical window and drawing the turtles. It also uses the `random` module to make each turtle move a random distance.

## Running the Script

To run the script, simply navigate to the directory containing the script and type `python3 turtle_race.py` in your terminal.

Enjoy the game!
